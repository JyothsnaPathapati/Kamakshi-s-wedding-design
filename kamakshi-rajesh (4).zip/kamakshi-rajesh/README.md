# Kamakshi & Rajesh — Wedding Invitation Website

Plain HTML + CSS + JavaScript. No npm, no build step.

## 1. Open in VS Code
File → Open Folder → choose `kamakshi-rajesh`.

## 2. Run locally
Install the **Live Server** extension (Ctrl+Shift+X, search "Live Server", Install). Right-click `index.html` → **Open with Live Server**.

## 3. Add your photos (nothing breaks if a file is missing)
| File | Used for |
|---|---|
| `assets/images/hero/couple.jpg` | Arch photo in the hero (portrait, about 4:5) |
| `assets/images/gallery/photo-01.jpg` … `photo-09.jpg` | Gallery. The section appears only if photos exist |

To use other file names or more photos, edit `GALLERY_PHOTOS` at the top of `js/script.js`.

## 4. Change text
Everything is in `index.html`. Search for the text and edit it. Date and time: the `#details` section.
The spelling "Muhurrtham" is kept exactly as on the original site.

## 5. Change colours
`:root` variables at the top of `css/style.css`.

## 6. Animations
- Opening sequence timings: `.intro` rules (section 4 of the CSS), the `animation-delay` values.
- Petals: count and speed in `startPetals()` in `js/script.js`.
- Garland sway / lamp flicker: `@keyframes sway` and `flicker` in the CSS.
- Users with "reduce motion" enabled see a static, fully readable page.

## 7. Music
Put an MP3 at `assets/music/wedding.mp3` (use music you have rights to). It never autoplays; the round button at bottom-right toggles it. Without the file, a small note appears.

## 8. Decorations
Garlands, lamps, lotus, banana leaves and the toran strip are vector SVGs drawn for this project (`assets/images/decorations`, `flowers`). To use photographic PNGs, overwrite those files with your own using the same names (or change the paths in `index.html`).
The Google Maps button is a search link built from the venue name and address; replace its `href` with your exact map link if you have one.

## 9. Deploy on Netlify
1. Sign up at netlify.com.
2. Sites → **Add new site → Deploy manually**.
3. Drag the whole `kamakshi-rajesh` folder into the box. You get a `*.netlify.app` link.
4. Site settings → Change site name to pick a nicer address.

## 10. Custom domain
Domain management → **Add a domain** → enter it → at your registrar either point nameservers to Netlify (shown on screen) or add the DNS records Netlify lists. HTTPS is issued automatically.
