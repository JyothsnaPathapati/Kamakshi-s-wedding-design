/* =====================================================
   Kamakshi & Rajesh — Wedding Invitation
   Edit the CONFIG block below to change dates and photos.
   ===================================================== */
(() => {
  "use strict";

  /* ---------- CONFIG ---------- */
  const GALLERY_PHOTOS = [                          // files inside assets/images/gallery/
    "photo-01.jpg", "photo-02.jpg", "photo-03.jpg",
    "photo-04.jpg", "photo-05.jpg", "photo-06.jpg",
    "photo-07.jpg", "photo-08.jpg", "photo-09.jpg"
  ];
  const GALLERY_DIR = "assets/images/gallery/";
  const HERO_PHOTO = "assets/images/hero/couple.jpg";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const isSmall = window.matchMedia("(max-width: 760px)").matches;

  /* ---------- Check whether an image file exists ---------- */
  const imageExists = (src) => new Promise((resolve) => {
    const probe = new Image();
    probe.onload = () => resolve(true);
    probe.onerror = () => resolve(false);
    probe.src = src;
  });

  /* ---------- Falling petals ---------- */
  let petalsStarted = false;
  function startPetals() {
    if (petalsStarted || reducedMotion) return;
    petalsStarted = true;
    const layer = $("#petals");
    const count = isSmall ? 10 : 22;
    for (let i = 0; i < count; i++) {
      const petal = document.createElement("span");
      petal.className = "petal";
      const size = 12 + Math.random() * 14;
      petal.style.cssText =
        `--l:${Math.random() * 100}%;--s:${size}px;--dur:${9 + Math.random() * 9}s;` +
        `--delay:${-Math.random() * 14}s;--drift:${(Math.random() - 0.5) * 220}px;` +
        `--spin:${(Math.random() > 0.5 ? 1 : -1) * (180 + Math.random() * 360)}deg`;
      layer.appendChild(petal);
    }
  }

  /* ---------- Intro / opening screen ---------- */
  const intro = $("#intro");
  function closeIntro() {
    if (!intro || intro.classList.contains("is-leaving")) return;
    intro.classList.add("is-leaving");
    document.body.classList.remove("is-locked");
    window.scrollTo(0, 0);
    startPetals();
    setTimeout(() => intro.remove(), 1000);
  }
  if (intro) {
    if (!reducedMotion) setTimeout(startPetals, 3200); // petals begin during the intro
    // The intro plays by itself, then opens the invitation automatically
    setTimeout(closeIntro, reducedMotion ? 1500 : 7500);
  } else {
    document.body.classList.remove("is-locked");
  }

  /* ---------- Scroll reveal ---------- */
  $$(".reveal").forEach((el) => el.style.setProperty("--i", el.dataset.delay || 0));
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add("is-visible"); revealObserver.unobserve(entry.target); }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  const observeReveals = () => $$(".reveal:not(.is-visible)").forEach((el) => revealObserver.observe(el));
  observeReveals();

  /* ---------- Navigation ---------- */
  const navToggle = $("#navToggle");
  const navLinks = $("#navLinks");
  function setMenu(open) {
    navLinks.classList.toggle("is-open", open);
    navToggle.setAttribute("aria-expanded", String(open));
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  }
  navToggle.addEventListener("click", () => setMenu(!navLinks.classList.contains("is-open")));
  navLinks.addEventListener("click", (e) => { if (e.target.closest("a")) setMenu(false); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") setMenu(false); });

  const navAnchors = $$(".nav__links a");
  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      navAnchors.forEach((a) => a.classList.toggle("is-active", a.getAttribute("href") === `#${entry.target.id}`));
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  $$("main section[id]").forEach((s) => sectionObserver.observe(s));

  /* ---------- Hero photo (shown only if the file exists) ---------- */
  imageExists(HERO_PHOTO).then((ok) => { if (ok) $("#heroPhoto").hidden = false; observeReveals(); });

  /* ---------- Gallery + lightbox (only photos that exist are shown) ---------- */
  const grid = $("#galleryGrid");
  const lightbox = $("#lightbox");
  const lightboxImg = $("#lightboxImg");
  const lightboxCount = $("#lightboxCount");
  const loadedPhotos = [];
  let current = 0;
  let lastFocus = null;

  async function buildGallery() {
    const checks = await Promise.all(GALLERY_PHOTOS.map((name) => imageExists(GALLERY_DIR + name)));
    GALLERY_PHOTOS.forEach((name, i) => { if (checks[i]) loadedPhotos.push(GALLERY_DIR + name); });
    if (!loadedPhotos.length) return;
    loadedPhotos.forEach((src, i) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "gallery__item reveal";
      btn.style.setProperty("--i", i % 3);
      btn.setAttribute("aria-label", `Open photo ${i + 1} of ${loadedPhotos.length}`);
      const img = document.createElement("img");
      img.src = src; img.alt = `Kamakshi and Rajesh, photo ${i + 1}`; img.loading = "lazy"; img.decoding = "async";
      btn.appendChild(img);
      btn.addEventListener("click", () => openLightbox(i));
      grid.appendChild(btn);
    });
    $("#gallery").hidden = false;
    $("#galleryLink").hidden = false;
    sectionObserver.observe($("#gallery"));
    observeReveals();
  }

  function showPhoto(index) {
    current = (index + loadedPhotos.length) % loadedPhotos.length;
    lightboxImg.src = loadedPhotos[current];
    lightboxImg.alt = `Photo ${current + 1} of ${loadedPhotos.length}`;
    lightboxCount.textContent = `${current + 1} / ${loadedPhotos.length}`;
  }
  function openLightbox(index) {
    lastFocus = document.activeElement;
    showPhoto(index);
    lightbox.hidden = false;
    document.body.classList.add("is-locked");
    $(".lightbox__close", lightbox).focus();
  }
  function closeLightbox() {
    lightbox.hidden = true;
    document.body.classList.remove("is-locked");
    if (lastFocus) lastFocus.focus();
  }
  $(".lightbox__close", lightbox).addEventListener("click", closeLightbox);
  $(".lightbox__nav--prev", lightbox).addEventListener("click", () => showPhoto(current - 1));
  $(".lightbox__nav--next", lightbox).addEventListener("click", () => showPhoto(current + 1));
  lightbox.addEventListener("click", (e) => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener("keydown", (e) => {
    if (lightbox.hidden) return;
    if (e.key === "Escape") closeLightbox();
    if (e.key === "ArrowLeft") showPhoto(current - 1);
    if (e.key === "ArrowRight") showPhoto(current + 1);
  });
  let touchStartX = 0;
  lightbox.addEventListener("touchstart", (e) => { touchStartX = e.changedTouches[0].clientX; }, { passive: true });
  lightbox.addEventListener("touchend", (e) => {
    const dx = e.changedTouches[0].clientX - touchStartX;
    if (Math.abs(dx) > 50) showPhoto(current + (dx < 0 ? 1 : -1));
  }, { passive: true });
  buildGallery();

  /* ---------- Background music (never autoplays) ---------- */
  const audio = $("#bgMusic");
  const musicBtn = $("#musicBtn");
  const musicNote = $("#musicNote");
  function setMusicState(playing) {
    musicBtn.setAttribute("aria-pressed", String(playing));
    musicBtn.setAttribute("aria-label", playing ? "Pause music" : "Play music");
    musicBtn.title = playing ? "Pause music" : "Play music";
  }
  function musicMissing() {
    setMusicState(false);
    musicNote.textContent = "Add assets/music/wedding.mp3 to enable music.";
    musicNote.hidden = false;
    setTimeout(() => { musicNote.hidden = true; }, 4000);
  }
  musicBtn.addEventListener("click", () => {
    if (!audio.paused) { audio.pause(); setMusicState(false); return; }
    audio.play().then(() => setMusicState(true)).catch(musicMissing);
  });
  audio.addEventListener("error", musicMissing);
})();
